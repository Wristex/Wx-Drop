fx_version 'cerulean'
game 'gta5'

author 'WX-dev'
description 'WX-DEV Advanced Drop Script'
version '1.0.0'

-- Config file
shared_script 'config.lua'

-- Client scripts
client_scripts {
    'client/client.lua',
    'client/manual_drop.lua'
}

-- Server script
server_script 'server/server.lua'
