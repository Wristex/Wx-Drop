
local QBCore = exports['qb-core']:GetCoreObject()

local dropLocation = Config.DropLocation
local dropInterval = Config.DropInterval


local function createDrop()
    TriggerClientEvent('drop:spawn', -1, dropLocation)
    TriggerClientEvent('drop:notify', -1, "Drop Belirtilen Noktaya İndi")
end


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(dropInterval)
        createDrop()
    end
end)

RegisterNetEvent('drop:giveReward')
AddEventHandler('drop:giveReward', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        for _, reward in pairs(Config.Rewards) do
            Player.Functions.AddItem(reward.name, reward.amount)
        end
    end
end)
RegisterNetEvent('qb-drops:giveReward')
AddEventHandler('qb-drops:giveReward', function(itemName, amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    
    if itemName == 'bandage' then
        Player.Functions.AddItem('bandage', amount)  
        TriggerClientEvent('QBCore:Notify', src, "Başarıyla " .. amount .. " Bandage ödülü aldınız!", "success")
    elseif itemName == 'heavyarmor' then
        Player.Functions.AddItem('heavyarmor', amount)    
        TriggerClientEvent('QBCore:Notify', src, "Başarıyla " .. amount .. " Heavy Armor ödülü aldınız!", "success")
    elseif itemName == 'water' then
        Player.Functions.AddItem('water', amount)     
        TriggerClientEvent('QBCore:Notify', src, "Başarıyla " .. amount .. " Su ödülü aldınız!", "success")
    elseif itemName == 'medkit' then
        Player.Functions.AddItem('medkit', amount)    
        TriggerClientEvent('QBCore:Notify', src, "Başarıyla " .. amount .. " Medkit ödülü aldınız!", "success")
    end
end)
