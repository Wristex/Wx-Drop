Config = {}

-- Drop'ların düşeceği bölgeyi tanımlayın (x, y, z)
Config.DropLocation = vector3(2719.69, 1358.55, 24.52) -- Örnek konum, kendi konumunuzu buraya girin

-- Drop düşme süresi (milisaniye cinsinden)
Config.DropInterval = 15 * 60 * 1000 -- 15 Dakika

-- Ödüller
Config.Rewards = {
    { name = 'bandage', amount = 5 },
    { name = 'heavyarmor', amount = 5 }
}
