Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.DropInterval)

        CreateDropWithSmoke(Config.DropLocation)
    end
end)

function CreateDropWithSmoke(location)
    local dropModel = `v_ind_meatdogpack` 
    RequestModel(dropModel)
    while not HasModelLoaded(dropModel) do
        Citizen.Wait(0)
    end

   
    local dropObject = CreateObject(dropModel, location.x, location.y, location.z + 50.0, true, true, true)
    FreezeEntityPosition(dropObject, true) 

   
    RequestNamedPtfxAsset("core")
    while not HasNamedPtfxAssetLoaded("core") do
        Citizen.Wait(0)
    end
    UseParticleFxAssetNextCall("core")
    local smokeEffect = StartParticleFxLoopedOnEntity(
        "exp_grd_grenade_smoke",  
         dropObject,
         0.0, 0.0, -0.5,  -- Dumanın konumu
         0.0, 0.0, 0.0,
         1.0,
         false, false, false
    )

   -- Blip 
   local dropBlip = AddBlipForCoord(location.x, location.y, location.z)
   SetBlipSprite(dropBlip, 1) 
   SetBlipColour(dropBlip, 1) 
   SetBlipScale(dropBlip, 0.7) 
   SetBlipAsShortRange(dropBlip, false) 

   -- Blip'in adı
   BeginTextCommandSetBlipName("STRING")
   AddTextComponentString("Drop Konumu")
   EndTextCommandSetBlipName(dropBlip)
    Citizen.CreateThread(function()
        local currentZ = location.z + 50.0
        while currentZ > location.z do
            Citizen.Wait(100) -- İniş hızı
            currentZ = currentZ - 0.3 -- İniş miktarı
            SetEntityCoords(dropObject, location.x, location.y, currentZ, false, false, false, true)
        end

        FreezeEntityPosition(dropObject, true)
        RemoveParticleFx(smokeEffect, false)

       
        MonitorDropPickup(dropObject)
    end)
end


function MonitorDropPickup(dropObject)
    Citizen.CreateThread(function()
        while DoesEntityExist(dropObject) do
            Citizen.Wait(0)

            local player = PlayerPedId()
            local playerCoords = GetEntityCoords(player)
            local dropCoords = GetEntityCoords(dropObject)
            local distance = #(playerCoords - dropCoords)

            if distance < 2.0 then -- Oyuncu yakınsa
                DisplayHelpText("Drop'u almak için ~INPUT_CONTEXT~ tuşuna bas") -- E tuşu varsayılan
                if IsControlJustReleased(0, 38) then -- E tuşu (varsayılan)
                    TriggerEvent('chat:addMessage', { 
                        args = { "Drop aldınız!" }
                    })

                    
                    GiveReward()

                    DeleteObject(dropObject) 
                end
            end
        end
    end)
end


function GiveReward()
    
    for _, reward in ipairs(Config.Rewards) do
        
        TriggerServerEvent('qb-drops:giveReward', reward.name, reward.amount)
    end
end


function DisplayHelpText(text)
    SetTextComponentFormat('STRING')
    AddTextComponentString(text)
    DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end
