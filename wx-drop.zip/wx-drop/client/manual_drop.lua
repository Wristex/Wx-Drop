RegisterCommand("dropat", function(source, args, rawCommand)
    
    if not IsPlayerAdmin() then
        print("Bu komutu sadece admin menüsüne erişimi olanlar kullanabilir!")
        return
    end

   
    print("Drop atma komutu çalıştı!") 
    CreateDropWithSmoke(Config.DropLocation)
end, false)


function IsPlayerAdmin()
    local playerId = PlayerId()

   
    local isAdmin = IsPlayerAceAllowed(playerId, "group.admin")

    if isAdmin then
        print("Admin menüsüne erişimi var.")
    else
        print("Admin menüsüne erişimi yok.")
    end
    return isAdmin
end
